document.querySelector('.cont-btn').addEventListener('click', function() {
    window.location.href = "http://yasirumacbook.hopto.org:81/TopUplk/";
});